export const SERVICES = [
  {
    id: "basic",
    name: "BASIC",
    price: 4000,
    displayPrice: "$40",
    tagline: "Essential exterior & interior refresh",
    features: [
      "Premium Hand Wash",
      "Rim & Tire Clean",
      "Vacuum",
      "Door Jam & Inside Window Clean"
    ],
    popular: false
  },
  {
    id: "gold",
    name: "GOLD",
    price: 8000,
    displayPrice: "$80",
    tagline: "Complete interior care with shine",
    features: [
      "Everything in Basic",
      "Interior Wipe Down (Dashboard, Doors, Console, Cup Holders, Plastic/Vinyl)",
      "Interior Shine"
    ],
    popular: true
  },
  {
    id: "elite",
    name: "ELITE",
    price: 12500,
    displayPrice: "$125",
    tagline: "Full deep clean with shampoo & deodorize",
    features: [
      "Everything in Gold",
      "Carpet & Seat Shampoo",
      "Deodorize"
    ],
    popular: false
  },
  {
    id: "semi-truck",
    name: "SEMI TRUCK INTERIOR",
    price: 12500,
    displayPrice: "$125",
    tagline: "Professional interior detailing for semi trucks",
    features: [
      "Complete Interior Vacuum",
      "Dashboard & Console Cleaning",
      "Door Panels & Interior Surfaces Wiped Down",
      "Cup Holders & Storage Areas Cleaned",
      "Window Cleaning (Inside)",
      "Trash Removal"
    ],
    popular: false
  }
];

export function getServiceById(id: string) {
  return SERVICES.find(s => s.id === id);
}