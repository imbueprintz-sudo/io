const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React from 'react';
import { Droplets, Shield, Clock, MapPin, ChevronRight } from 'lucide-react';

const HERO_IMG = 'https://media.db.com/images/public/6a6fc99997cbacfbf1f3494a/0b505cb26_generated_image.png';

const FEATURES = [
  { icon: Droplets, label: 'Premium Products' },
  { icon: Shield, label: 'Attention to Detail' },
  { icon: Clock, label: 'Save Time & Stress' },
  { icon: MapPin, label: 'We Come to You' },
];

export default function Hero() {
  return (
    <section id="top" className="relative min-h-screen flex items-center overflow-hidden">
      <div className="absolute inset-0">
        <img src={HERO_IMG} alt="" className="w-full h-full object-cover opacity-40" />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/80 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-background/60" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full pt-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="font-display text-6xl sm:text-7xl lg:text-8xl font-black uppercase leading-[0.9] text-foreground mb-4">
              We Come<br /><span className="text-primary text-glow">To You</span>
            </h1>

            <p className="font-heading text-lg sm:text-xl uppercase tracking-wide text-muted-foreground mb-10 max-w-lg">
              Professional Detailing. Premium Results. Anytime. Anywhere.
            </p>

            <div className="flex flex-wrap gap-4">
              <a href="#booking" className="group flex items-center gap-2 bg-primary text-primary-foreground px-8 py-4 font-mono text-sm uppercase tracking-widest hover:bg-primary/90 transition-colors">
                Book Appointment
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </a>
              <a href="#services" className="border border-border px-8 py-4 font-mono text-sm uppercase tracking-widest text-foreground hover:border-primary hover:text-primary transition-colors">
                View Services
              </a>
            </div>
          </div>

          <div className="hidden lg:flex flex-col gap-3">
            {FEATURES.map((f, i) => (
              <div key={i} className="flex items-center gap-4 border border-border bg-card/50 backdrop-blur-sm px-6 py-4 hover:border-primary/50 transition-colors group">
                <div className="w-10 h-10 flex items-center justify-center border border-primary/30 text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                  <f.icon className="w-5 h-5" />
                </div>
                <span className="font-heading text-sm uppercase tracking-wider text-foreground">{f.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 h-px bg-border" />
    </section>
  );
}