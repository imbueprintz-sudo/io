const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React from 'react';
import { Phone, Mail, Calendar } from 'lucide-react';
import { CONTACT_INFO } from '@/lib/services';

const LOGO_URL = 'https://media.db.com/images/public/user_6a6fc90739ee8ac0cbe82120/f60829ca8_5118616417514228901.jpg';

export default function Footer() {
  return (
    <footer className="relative border-t border-border bg-card/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <p className="font-heading text-lg uppercase tracking-widest text-foreground mb-8">
            {CONTACT_INFO.tagline}
          </p>

          <a href={`tel:${CONTACT_INFO.phoneRaw}`} className="inline-flex items-center gap-4 mb-8 group">
            <div className="w-14 h-14 flex items-center justify-center border border-primary/30 text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
              <Phone className="w-6 h-6" />
            </div>
            <span className="font-display text-4xl sm:text-5xl font-black text-foreground">{CONTACT_INFO.phone}</span>
          </a>

          <div className="flex flex-wrap items-center justify-center gap-6 sm:gap-10 mb-10">
            <a href={`mailto:${CONTACT_INFO.email}`} className="flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors">
              <Mail className="w-4 h-4" /> <span className="font-mono text-xs uppercase tracking-wider">{CONTACT_INFO.email}</span>
            </a>

          </div>

          <div className="inline-flex items-center gap-3 border border-primary/30 border-glow px-6 py-3">
            <Calendar className="w-5 h-5 text-primary" />
            <span className="font-mono text-xs uppercase tracking-widest text-foreground">Schedule Your Appointment Today</span>
          </div>
          <p className="font-heading text-sm uppercase tracking-wide text-muted-foreground mt-4">
            Experience the City2City Difference
          </p>
        </div>

        <div className="border-t border-border pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <img src={LOGO_URL} alt="City2City Mobile Auto Detailing" className="h-16 w-auto object-contain opacity-80" />
          <p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
            © {new Date().getFullYear()} City2City Mobile Auto Detailing · All Rights Reserved
          </p>
        </div>
      </div>
    </footer>
  );
}