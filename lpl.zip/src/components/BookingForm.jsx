const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from 'react';
import { Calendar, Clock, MapPin, User, Mail, Phone, Loader2, CheckCircle2, AlertCircle } from 'lucide-react';

import { SERVICES, TIME_SLOTS } from '@/lib/services';

export default function BookingForm() {
  const [form, setForm] = useState({
    serviceId: '',
    date: '',
    time: '',
    name: '',
    email: '',
    phone: '',
    address: '',
    notes: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const today = new Date().toISOString().split('T')[0];

  const update = (field, value) => setForm(prev => ({ ...prev, [field]: value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (!form.serviceId || !form.date || !form.time || !form.name || !form.email || !form.phone || !form.address) {
      setError('Please fill in all required fields.');
      return;
    }

    setLoading(true);
    try {
      const service = SERVICES.find(s => s.id === form.serviceId);
      await db.entities.Appointment.create({
        service_id: form.serviceId,
        service_name: service.name,
        price: service.price,
        customer_name: form.name,
        customer_email: form.email,
        customer_phone: form.phone,
        appointment_date: form.date,
        appointment_time: form.time,
        location_address: form.address,
        notes: form.notes || '',
        status: 'confirmed'
      });
      setSuccess(true);
    } catch (err) {
      setError(err.message || 'Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const inputClass = "w-full bg-background border border-border px-4 py-3 pl-11 text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary transition-colors font-body text-sm";
  const labelClass = "font-mono text-xs uppercase tracking-widest text-muted-foreground mb-2 block";

  return (
    <section id="booking" className="relative py-24 border-t border-border">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-12 text-center">
          <h2 className="font-display text-5xl sm:text-6xl font-black uppercase text-foreground">
            Book Your <span className="text-primary">Appointment</span>
          </h2>
          <p className="font-body text-muted-foreground mt-4">Select a service, pick your time, and we'll come to you.</p>
        </div>

        {success ? (
          <div className="border border-primary/30 border-glow bg-card p-10 text-center">
            <CheckCircle2 className="w-20 h-20 text-primary mx-auto mb-6" />
            <h3 className="font-display text-4xl font-black uppercase text-foreground mb-3">Appointment Booked</h3>
            <p className="font-body text-muted-foreground mb-2">We've received your booking request!</p>
            <p className="font-mono text-xs uppercase tracking-widest text-primary mb-8">We'll see you soon</p>
            <button
              onClick={() => {
                setSuccess(false);
                setForm({ serviceId: '', date: '', time: '', name: '', email: '', phone: '', address: '', notes: '' });
              }}
              className="bg-primary text-primary-foreground px-8 py-3 font-mono text-xs uppercase tracking-widest hover:bg-primary/90 transition-colors"
            >
              Book Another
            </button>
          </div>
        ) : (
        <form onSubmit={handleSubmit} className="border border-border bg-card p-6 sm:p-10 space-y-6">
          <div>
            <label className={labelClass}>Service *</label>
            <div className="grid sm:grid-cols-2 gap-3">
              {SERVICES.map(s => (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => update('serviceId', s.id)}
                  className={`text-left p-4 border transition-colors ${form.serviceId === s.id ? 'border-primary bg-primary/10 border-glow' : 'border-border hover:border-primary/50'}`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-heading text-sm uppercase tracking-wide text-foreground">{s.name}</span>
                    <span className="font-display text-xl font-black text-primary">{s.displayPrice}</span>
                  </div>
                  <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">{s.tagline}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className={labelClass}>Date *</label>
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                <input type="date" min={today} value={form.date} onChange={e => update('date', e.target.value)} className={inputClass} />
              </div>
            </div>
            <div>
              <label className={labelClass}>Time *</label>
              <div className="relative">
                <Clock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none z-10" />
                <select value={form.time} onChange={e => update('time', e.target.value)} className={inputClass + ' appearance-none cursor-pointer'}>
                  <option value="">Select time</option>
                  {TIME_SLOTS.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
            </div>
          </div>

          <div>
            <label className={labelClass}>Service Address *</label>
            <div className="relative">
              <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
              <input type="text" placeholder="Where should we detail your vehicle?" value={form.address} onChange={e => update('address', e.target.value)} className={inputClass} />
            </div>
          </div>

          <div className="grid sm:grid-cols-3 gap-4">
            <div>
              <label className={labelClass}>Name *</label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                <input type="text" placeholder="Your name" value={form.name} onChange={e => update('name', e.target.value)} className={inputClass} />
              </div>
            </div>
            <div>
              <label className={labelClass}>Email *</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                <input type="email" placeholder="you@email.com" value={form.email} onChange={e => update('email', e.target.value)} className={inputClass} />
              </div>
            </div>
            <div>
              <label className={labelClass}>Phone *</label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                <input type="tel" placeholder="Phone number" value={form.phone} onChange={e => update('phone', e.target.value)} className={inputClass} />
              </div>
            </div>
          </div>

          <div>
            <label className={labelClass}>Notes (Optional)</label>
            <textarea placeholder="Vehicle make/model, specific concerns, access instructions..." value={form.notes} onChange={e => update('notes', e.target.value)} rows={3} className="w-full bg-background border border-border px-4 py-3 text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary transition-colors font-body text-sm resize-none" />
          </div>

          {error && (
            <div className="flex items-center gap-2 border border-destructive/50 bg-destructive/10 px-4 py-3 text-sm text-destructive">
              <AlertCircle className="w-4 h-4 shrink-0" />
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full flex items-center justify-center gap-2 bg-primary text-primary-foreground py-4 font-mono text-sm uppercase tracking-widest hover:bg-primary/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? (
              <><Loader2 className="w-4 h-4 animate-spin" /> Processing...</>
            ) : (
              <><CheckCircle2 className="w-4 h-4" /> Book Now</>
            )}
          </button>

        </form>
        )}
      </div>
    </section>
  );
}