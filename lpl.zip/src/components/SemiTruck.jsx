import React from 'react';
import { Truck, SprayCan, Shield, Clock, ThumbsUp, Check } from 'lucide-react';

const HIGHLIGHTS = [
  { icon: Truck, label: 'Mobile Service', sub: 'We Come to You' },
  { icon: SprayCan, label: 'Premium Products', sub: 'Professional Grade' },
  { icon: Shield, label: 'Professional Equipment', sub: 'Industry Standard' },
  { icon: Clock, label: 'Save Time & Downtime', sub: 'On Your Schedule' },
  { icon: ThumbsUp, label: 'Quality Service', sub: 'You Can Trust' },
];

const CHECKLIST = [
  'Complete Interior Vacuum',
  'Dashboard & Console Cleaning',
  'Door Panels & Interior Surfaces Wiped Down',
  'Cup Holders & Storage Areas Cleaned',
  'Window Cleaning (Inside)',
  'Trash Removal',
];

export default function SemiTruck() {
  return (
    <section id="semi-truck" className="relative py-24 border-t border-border bg-card/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-16">
          <h2 className="font-display text-4xl sm:text-5xl lg:text-6xl font-black uppercase text-foreground leading-tight">
            Professional Interior Detailing<br /><span className="text-primary">for Semi Trucks</span>
          </h2>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          <div className="border border-primary/30 border-glow bg-card p-8">
            <div className="font-mono text-xs uppercase tracking-widest text-muted-foreground mb-2">Interior Clean Only</div>
            <div className="flex items-baseline gap-2 mb-6 pb-6 border-b border-border">
              <span className="font-display text-6xl font-black text-primary">$125</span>
              <span className="font-mono text-sm text-muted-foreground">/ truck</span>
            </div>
            <ul className="space-y-3 mb-8">
              {CHECKLIST.map((item, i) => (
                <li key={i} className="flex items-start gap-3 text-sm text-foreground">
                  <Check className="w-4 h-4 text-primary mt-0.5 shrink-0" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
            <a href="#booking" className="block text-center bg-primary text-primary-foreground py-3 font-mono text-xs uppercase tracking-widest hover:bg-primary/90 transition-colors">
              Book Semi Truck Detail
            </a>
          </div>

          <div>
            <div className="grid grid-cols-1 gap-4 mb-8">
              {[
                { icon: Shield, title: 'Cleaner Cab', sub: 'A Healthier You' },
                { icon: Truck, title: 'Better Comfort', sub: 'On The Road' },
                { icon: ThumbsUp, title: 'Better Impression', sub: 'On Every Delivery' },
              ].map((b, i) => (
                <div key={i} className="flex items-center gap-4 border border-border p-5 hover:border-primary/50 transition-colors">
                  <div className="w-12 h-12 flex items-center justify-center border border-primary/30 text-primary shrink-0">
                    <b.icon className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="font-heading text-lg uppercase tracking-wide text-foreground">{b.title}</div>
                    <div className="font-mono text-xs uppercase tracking-widest text-muted-foreground">{b.sub}</div>
                  </div>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-px bg-border border border-border">
              {HIGHLIGHTS.map((h, i) => (
                <div key={i} className="bg-background p-4 text-center">
                  <h.icon className="w-6 h-6 text-primary mx-auto mb-2" />
                  <div className="font-mono text-[10px] uppercase tracking-wider text-foreground leading-tight">{h.label}</div>
                  <div className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground leading-tight">{h.sub}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}