const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from 'react';
import { Menu, X, Phone } from 'lucide-react';
import { CONTACT_INFO } from '@/lib/services';

const LOGO_URL = 'https://media.db.com/images/public/user_6a6fc90739ee8ac0cbe82120/f60829ca8_5118616417514228901.jpg';

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const links = [
    { label: 'Services', href: '#services' },
    { label: 'Semi Trucks', href: '#semi-truck' },
    { label: 'Book', href: '#booking' },
    { label: 'Contact', href: '#contact' },
  ];

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'bg-background/95 backdrop-blur-md border-b border-border' : 'bg-transparent'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <a href="#top" className="flex items-center gap-3">
            <img src={LOGO_URL} alt="City2City Mobile Auto Detailing" className="h-16 w-auto object-contain" />
          </a>

          <nav className="hidden md:flex items-center gap-8">
            {links.map(l => (
              <a key={l.href} href={l.href} className="font-mono text-xs uppercase tracking-widest text-muted-foreground hover:text-primary transition-colors">
                {l.label}
              </a>
            ))}
            <a href={`tel:${CONTACT_INFO.phoneRaw}`} className="flex items-center gap-2 border border-primary/40 px-4 py-2 font-mono text-xs uppercase tracking-widest text-primary hover:bg-primary hover:text-primary-foreground transition-colors">
              <Phone className="w-3.5 h-3.5" />
              {CONTACT_INFO.phone}
            </a>
          </nav>

          <button className="md:hidden text-foreground" onClick={() => setOpen(!open)} aria-label="Toggle menu">
            {open ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {open && (
        <div className="md:hidden bg-background/98 backdrop-blur-md border-b border-border">
          <nav className="flex flex-col px-6 py-4 gap-4">
            {links.map(l => (
              <a key={l.href} href={l.href} onClick={() => setOpen(false)} className="font-mono text-sm uppercase tracking-widest text-muted-foreground hover:text-primary">
                {l.label}
              </a>
            ))}
            <a href={`tel:${CONTACT_INFO.phoneRaw}`} className="flex items-center gap-2 font-mono text-sm uppercase tracking-widest text-primary">
              <Phone className="w-4 h-4" /> {CONTACT_INFO.phone}
            </a>
          </nav>
        </div>
      )}
    </header>
  );
}