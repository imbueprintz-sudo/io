const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from 'react';
import { User, Mail, Phone, Loader2, CheckCircle2, AlertCircle, Send } from 'lucide-react';

import { CONTACT_INFO } from '@/lib/services';

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', phone: '', message: '' });
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState('');

  const update = (field, value) => setForm(prev => ({ ...prev, [field]: value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    if (!form.name || !form.email || !form.message) {
      setError('Name, email, and message are required.');
      return;
    }
    setLoading(true);
    try {
      await db.functions.invoke('send-contact-message', form);
      setSent(true);
      setForm({ name: '', email: '', phone: '', message: '' });
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to send message. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const inputClass = "w-full bg-background border border-border px-4 py-3 pl-11 text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary transition-colors font-body text-sm";
  const labelClass = "font-mono text-xs uppercase tracking-widest text-muted-foreground mb-2 block";

  return (
    <section id="contact" className="relative py-24 border-t border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16">
          <div>
            <h2 className="font-display text-5xl sm:text-6xl font-black uppercase text-foreground mb-6">
              Get In <span className="text-primary">Touch</span>
            </h2>
            <p className="font-body text-muted-foreground mb-10 max-w-md">
              Have a custom request or question? Send us a message and we'll get back to you fast.
            </p>

            <div className="space-y-px bg-border border border-border">
              <a href={`tel:${CONTACT_INFO.phoneRaw}`} className="flex items-center gap-4 bg-background p-5 hover:bg-card transition-colors group">
                <div className="w-12 h-12 flex items-center justify-center border border-primary/30 text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors shrink-0">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <div className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Call Us</div>
                  <div className="font-heading text-lg text-foreground">{CONTACT_INFO.phone}</div>
                </div>
              </a>
              <a href={`mailto:${CONTACT_INFO.email}`} className="flex items-center gap-4 bg-background p-5 hover:bg-card transition-colors group">
                <div className="w-12 h-12 flex items-center justify-center border border-primary/30 text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors shrink-0">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <div className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Email Us</div>
                  <div className="font-heading text-lg text-foreground break-all">{CONTACT_INFO.email}</div>
                </div>
              </a>
            </div>
          </div>

          <div>
            {sent ? (
              <div className="border border-primary/30 border-glow bg-card p-10 text-center flex flex-col items-center gap-4 min-h-[400px] justify-center">
                <CheckCircle2 className="w-16 h-16 text-primary" />
                <h3 className="font-display text-3xl font-black uppercase text-foreground">Message Sent</h3>
                <p className="font-body text-muted-foreground">We'll get back to you shortly.</p>
                <button onClick={() => setSent(false)} className="font-mono text-xs uppercase tracking-widest text-primary border border-primary/40 px-6 py-2 hover:bg-primary hover:text-primary-foreground transition-colors">
                  Send Another
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="border border-border bg-card p-6 sm:p-8 space-y-5">
                <div>
                  <label className={labelClass}>Name *</label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                    <input type="text" placeholder="Your name" value={form.name} onChange={e => update('name', e.target.value)} className={inputClass} />
                  </div>
                </div>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className={labelClass}>Email *</label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                      <input type="email" placeholder="you@email.com" value={form.email} onChange={e => update('email', e.target.value)} className={inputClass} />
                    </div>
                  </div>
                  <div>
                    <label className={labelClass}>Phone</label>
                    <div className="relative">
                      <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                      <input type="tel" placeholder="Optional" value={form.phone} onChange={e => update('phone', e.target.value)} className={inputClass} />
                    </div>
                  </div>
                </div>
                <div>
                  <label className={labelClass}>Message *</label>
                  <textarea placeholder="Tell us about your vehicle and what you need..." value={form.message} onChange={e => update('message', e.target.value)} rows={5} className="w-full bg-background border border-border px-4 py-3 text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary transition-colors font-body text-sm resize-none" />
                </div>

                {error && (
                  <div className="flex items-center gap-2 border border-destructive/50 bg-destructive/10 px-4 py-3 text-sm text-destructive">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    {error}
                  </div>
                )}

                <button type="submit" disabled={loading} className="w-full flex items-center justify-center gap-2 bg-primary text-primary-foreground py-4 font-mono text-sm uppercase tracking-widest hover:bg-primary/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed">
                  {loading ? <><Loader2 className="w-4 h-4 animate-spin" /> Sending...</> : <><Send className="w-4 h-4" /> Send Message</>}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}