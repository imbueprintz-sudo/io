import React from 'react';
import { Check, Crown } from 'lucide-react';
import { SERVICES } from '@/lib/services';

export default function Services() {
  const tiers = SERVICES.filter(s => s.id !== 'semi-truck');

  return (
    <section id="services" className="relative py-24 border-t border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-16">
          <h2 className="font-display text-5xl sm:text-6xl font-black uppercase text-foreground">
            Choose Your <span className="text-primary">Detail</span>
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-px bg-border">
          {tiers.map((service) => (
            <div
              key={service.id}
              className={`relative bg-card p-8 flex flex-col ${service.popular ? 'border-2 border-primary border-glow md:-mt-4 md:mb-4' : 'border border-border'}`}
            >
              {service.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground px-4 py-1 font-mono text-xs uppercase tracking-widest flex items-center gap-1.5">
                  <Crown className="w-3 h-3" /> Most Popular
                </div>
              )}

              <div className="font-mono text-xs uppercase tracking-widest text-muted-foreground mb-2">
                {service.tagline}
              </div>
              <h3 className="font-display text-3xl font-black uppercase text-foreground mb-4">{service.name}</h3>

              <div className="flex items-baseline gap-1 mb-8 pb-8 border-b border-border">
                <span className="font-display text-6xl font-black text-primary">{service.displayPrice}</span>
              </div>

              <ul className="space-y-3 mb-8 flex-1">
                {service.features.map((f, i) => (
                  <li key={i} className="flex items-start gap-3 text-sm text-muted-foreground">
                    <Check className="w-4 h-4 text-primary mt-0.5 shrink-0" />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>

              <a
                href="#booking"
                className={`text-center py-3 font-mono text-xs uppercase tracking-widest transition-colors ${service.popular ? 'bg-primary text-primary-foreground hover:bg-primary/90' : 'border border-border text-foreground hover:border-primary hover:text-primary'}`}
              >
                Book {service.name}
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}